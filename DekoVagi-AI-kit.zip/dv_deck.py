"""DekoVagi deck builder for AI assistants. Needs only python-pptx and Pillow (both are in ChatGPT's code tool).

    from dv_deck import Deck
    deck = Deck("DekoVagi-slaidid-mall-AI.pptx")
    print(deck.fields("D40"))                      # what this layout needs: field number, kind, limit, example
    deck.add("D40", {0: "Kliendi nimi\\n*Jõulupidu*", 11: "Sündmus", 10: "photos/hall.jpg"})
    deck.add("D55", {"background": "photos/hall.jpg", 0: "Peosaal, *õhtune valgus.*"})
    deck.save("pakkumine.pptx")
    print(deck.report())                           # anything left empty, not found or likely too long

Text: "\\n" starts a new line; *words between single stars* become the italic accent (burgundy on light slides, rose on dark).
Images: give a file path (JPG or PNG). Photos are cropped to fill their field; cut-outs (transparent PNG) are fitted whole.
Fields you leave out are removed from the slide. Fonts, sizes, colours and positions come from the template: never set them.
add() never raises for a bad value: it writes a note in report(). To redo a slide: deck.remove(n), then deck.add(..., position=n).
"""
import math
import os
import re
import tempfile
from PIL import Image, ImageOps
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import PP_PLACEHOLDER
from pptx.opc.packuri import PackURI
from pptx.oxml import parse_xml
from pptx.util import Emu

A = "http://schemas.openxmlformats.org/drawingml/2006/main"
P = "http://schemas.openxmlformats.org/presentationml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PT = 12700                                   # EMU per point
COLOURS = ("cream", "olive", "wine")
# layouts whose photo is the slide background (the card, fade and logo sit on top of it)
BACKGROUND_PHOTO = {"D41", "D55", "D56", "D67"}
# slides with fixed DekoVagi text (approach, contact): fields you do not give keep the standard text
STANDARD_TEXT = {"D9", "D31"}


class Deck:
    def __init__(self, template):
        self.prs = Presentation(template)
        self.layouts = {l.name.split(" ")[0]: l for l in self.prs.slide_layouts}      # "D40", "D4-olive", ...
        self.notes = []

    # ------------------------------------------------------------ looking things up
    def layout(self, lid, colour=None):
        """D40, or D4 with colour='olive' (or 'D4-olive'). Without a colour the cream version is used when there is one."""
        lid = str(lid).strip()
        if lid.isdigit():
            lid = "D" + lid
        lid = lid[:1].upper() + lid[1:].lower()
        base = lid.split("-")[0]
        colour = (colour or (lid.split("-")[1] if "-" in lid else "") or "").strip().lower() or None
        versions = [c for c in COLOURS if f"{base}-{c}" in self.layouts]
        if base not in self.layouts and not versions:
            raise KeyError(f"No layout {lid!r}. Known: {', '.join(sorted({k.split('-')[0] for k in self.layouts}, key=_num))}")
        if not versions:
            if colour:
                self.notes.append(f"{base} has no colour versions; colour {colour!r} was ignored")
            return base, self.layouts[base]
        if colour in versions:
            return f"{base}-{colour}", self.layouts[f"{base}-{colour}"]
        if colour:
            self.notes.append(f"{base} has no {colour!r} version (it has: {', '.join(versions)}); {versions[0]} was used")
        return f"{base}-{versions[0]}", self.layouts[f"{base}-{versions[0]}"]

    def catalogue(self):
        return [l.name for l in self.prs.slide_layouts]

    def field_list(self, lid, colour=None):
        """The fields of one layout as dicts: idx, kind (title, text, photo, cutout, table), note, and for text: lines, chars, example."""
        n = len(self.notes)
        key, layout = self.layout(lid, colour)
        del self.notes[n:]                                  # looking up fields is not a build step: no notes
        out = []
        if key.split("-")[0] in BACKGROUND_PHOTO:
            out.append({"idx": "background", "kind": "photo", "note": 'full-slide photo, ratio 3:2, given with the key "background"'})
        for ph in layout.placeholders:
            kind = _kind(ph)
            if kind is None:
                continue
            f = {"idx": ph.placeholder_format.idx, "kind": kind}
            prompt = _example(ph) if ph.has_text_frame else ""
            if kind == "photo":
                ratio = prompt.split("·")[-1].strip() if "·" in prompt else ""
                f["note"] = ("photo, any ratio (collage cell)" if not re.match(r"^\d+:\d+$", ratio) else f"photo, ratio {ratio}") + ", cropped to fill the field"
            elif kind == "cutout":
                f["note"] = "object on a transparent background (PNG), shown whole"
            elif kind == "table":
                f["note"] = "table: fill it by hand in PowerPoint"
            else:
                f["lines"], f["chars"] = _room(ph, prompt)
                f["example"] = prompt
                shown = prompt.replace("\n", " / ")
                f["note"] = f"max {f['lines']} line{'s' if f['lines'] > 1 else ''}, about {f['chars']} characters per line. Example: {shown}"
            out.append(f)
        return out

    def fields(self, lid, colour=None):
        """The fields of one layout, ready to print: [(number, kind, limit and example)]. In examples " / " marks a line break
        (write it as \\n) and *stars* mark the italic accent."""
        return [(f["idx"], f["kind"], f["note"]) for f in self.field_list(lid, colour)]

    # ------------------------------------------------------------ building
    def add(self, lid, fields=None, colour=None, position=None):
        """Add one slide. fields: {field number: text or image path}. position: slide number to insert at (default: the end)."""
        key, layout = self.layout(lid, colour)
        base = key.split("-")[0]
        lph = {ph.placeholder_format.idx: ph for ph in layout.placeholders}
        n = position if position else len(self.prs.slides) + 1
        where = f"slide {n} ({key})"
        given, images, failed = {}, {}, set()
        for k, v in (fields or {}).items():                 # check everything before the slide exists
            if str(k).strip().lower() == "background":
                path = _image(v)
                if path:
                    images["background"] = path
                    if base not in BACKGROUND_PHOTO:
                        self.notes.append(f"{where}: this layout has no background photo; it was set anyway and may hide the design")
                else:
                    self.notes.append(f"{where}: background image not found or not a JPG/PNG: {v!r}")
                continue
            try:
                idx = int(str(k).strip())
            except ValueError:
                self.notes.append(f"{where}: field {k!r} is not a field number; see deck.fields('{key}')")
                continue
            if idx not in lph:
                self.notes.append(f"{where}: there is no field {idx}; see deck.fields('{key}')")
                continue
            if idx in given:
                self.notes.append(f"{where}: field {idx} was given twice; the last value was used")
            kind = _kind(lph[idx])
            if kind in ("photo", "cutout"):
                path = _image(v)
                if not path:
                    self.notes.append(f"{where}: image for field {idx} not found or not a JPG/PNG: {v!r}; the field was removed")
                    given.pop(idx, None); failed.add(idx)
                    continue
                images[idx] = path
            elif kind in ("title", "text") and isinstance(v, str) and re.search(r"\.(jpe?g|png|webp|heic|gif)$", v.strip(), re.I):
                self.notes.append(f"{where}: field {idx} is a text field but got an image path: {v!r}")
            given[idx] = v
        slide = self.prs.slides.add_slide(layout)
        accent = _accent(layout)
        for ph in list(slide.placeholders):
            idx = ph.placeholder_format.idx
            kind = _kind(lph.get(idx, ph))
            value = given.get(idx)
            if value in (None, "", []) and base in STANDARD_TEXT and kind in ("title", "text"):
                value = _example(lph[idx])                  # standard slides keep their fixed text
            if value in (None, "", []):
                ph._element.getparent().remove(ph._element)
                if kind in ("title", "photo", "cutout") and idx not in failed:
                    self.notes.append(f"{where}: field {idx} ({kind}) left empty and removed")
                continue
            if kind in ("photo", "cutout"):
                self._picture(ph, lph[idx], images[idx], kind)
            elif kind == "table":
                self.notes.append(f"{where}: field {idx} is a table; fill it by hand in PowerPoint")
            else:
                text = _clean(value)
                if re.sub(r"\*([^*\n]+)\*", "", text).count("*"):
                    self.notes.append(f"{where}: field {idx} had an unpaired * which was removed")
                _write(ph.text_frame, text, accent)
                lines, chars = _room(lph[idx], _example(lph[idx]))
                need = _lines_needed(text, chars)
                if need > lines:
                    self.notes.append(f"{where}: field {idx} is probably too long (about {need} lines, room for {lines}): shorten it, "
                                      f"or check that it does not run into what is below")
        if "background" in images:
            _background(slide, images["background"], self.prs.slide_width, self.prs.slide_height)
        elif base in BACKGROUND_PHOTO:
            self.notes.append(f"{where}: this layout needs a 'background' photo")
        if position:
            self.move(len(self.prs.slides), position)
        return slide

    def remove(self, number):
        """Delete slide number `number` (1 = first)."""
        ids = self.prs.slides._sldIdLst
        el = list(ids)[number - 1]
        self.prs.part.drop_rel(el.get(f"{{{R}}}id"))
        ids.remove(el)
        for i, slide in enumerate(self.prs.slides, 1):      # keep part names unique, or the next add() would reuse one
            slide.part.partname = PackURI(f"/ppt/slides/slide{i}.xml")

    def move(self, number, to):
        """Move slide `number` to position `to` (1 = first)."""
        ids = self.prs.slides._sldIdLst
        el = list(ids)[number - 1]
        ids.remove(el)
        ids.insert(to - 1, el)

    def _picture(self, ph, layout_ph, path, kind):
        pic = ph.insert_picture(path)                       # python-pptx crops the image to fill the field
        if kind == "cutout":                               # a cut-out is shown whole, standing on the bottom of its field
            pic.crop_left = pic.crop_right = pic.crop_top = pic.crop_bottom = 0
            x, y, w, h = layout_ph.left, layout_ph.top, layout_ph.width, layout_ph.height
            with Image.open(path) as im:
                iw, ih = im.size
            s = min(w / iw, h / ih)
            pw, pht = int(iw * s), int(ih * s)
            align = (layout_ph._element.xpath("./p:nvSpPr/p:cNvPr/@descr") or ["cutout bottom"])[0]
            top = y if "top" in align else (y + (h - pht) // 2 if "center" in align else y + h - pht)
            pic.left, pic.top, pic.width, pic.height = Emu(x + (w - pw) // 2), Emu(top), Emu(pw), Emu(pht)
        else:                                              # keep the cream edge of overlapping photos
            ln = layout_ph._element.xpath("./p:spPr/a:ln[a:solidFill]")
            if ln:
                w = ln[0].get("w")
                rgb = ln[0].xpath("./a:solidFill/a:srgbClr/@val")
                if w and rgb:
                    pic.line.width = Emu(int(w)); pic.line.color.rgb = RGBColor.from_string(rgb[0])

    def save(self, path):
        self.prs.save(path)
        return path

    def report(self):
        return "\n".join(self.notes) if self.notes else "No problems found."


def _num(key):
    m = re.match(r"D(\d+)", key)
    return (int(m.group(1)) if m else 0, key)


def _image(value):
    """A path python-pptx can use, or None. Turns phone photos upright (EXIF) and converts other formats to JPG/PNG."""
    path = str(value).strip() if isinstance(value, (str, os.PathLike)) else ""
    if not path or not os.path.isfile(path):
        return None
    try:
        with Image.open(path) as im:
            if im.format in ("JPEG", "PNG") and im.getexif().get(0x0112, 1) in (1, None):
                return path
            upright = ImageOps.exif_transpose(im)
            alpha = upright.mode in ("RGBA", "LA", "P")
            fd, out = tempfile.mkstemp(suffix=".png" if alpha else ".jpg")
            os.close(fd)
            (upright.convert("RGBA") if alpha else upright.convert("RGB")).save(out, quality=92)
            return out
    except Exception:
        return None


def _kind(ph):
    t = ph.placeholder_format.type
    if t in (PP_PLACEHOLDER.TITLE, PP_PLACEHOLDER.CENTER_TITLE):
        return "title"
    if t == PP_PLACEHOLDER.PICTURE:
        return "cutout" if ph.name.startswith("Väljalõige") else "photo"
    if t == PP_PLACEHOLDER.TABLE:
        return "table"
    if t in (PP_PLACEHOLDER.BODY, PP_PLACEHOLDER.OBJECT):
        return "text"
    return None


def _example(ph):
    """Example text of a layout field; where a field mixes plain and italic words, the italic (accent) words are in *stars*."""
    paras = ph.text_frame.paragraphs
    mixed = len({bool(r.font.italic) for p in paras for r in p.runs if r.text.strip()}) > 1
    lines = []
    for p in paras:
        s = ""
        for r in p.runs:
            t = r.text
            s += ("*" + t.strip() + "*" + (" " if t.endswith(" ") else "")) if mixed and r.font.italic and t.strip() else t
        lines.append(s)
    return "\n".join(lines)


def _lines_needed(text, chars):
    return sum(max(1, math.ceil(len(line.replace("*", "")) / max(chars, 1))) for line in str(text).split("\n"))


def _room(layout_ph, example=""):
    """(lines that fit, rough characters per line) from the field's size and text style; never less than its own example needs."""
    el = layout_ph._element
    sz = el.xpath(".//a:lstStyle/a:lvl1pPr/a:defRPr/@sz")
    size = int(sz[0]) / 100 if sz else 18.0
    ln = el.xpath(".//a:lstStyle/a:lvl1pPr/a:lnSpc/a:spcPts/@val")
    line = int(ln[0]) / 100 if ln else size * 1.2
    face = (el.xpath(".//a:lstStyle/a:lvl1pPr/a:defRPr/a:latin/@typeface") or ["Hanken Grotesk"])[0]
    caps = bool(el.xpath(".//a:lstStyle/a:lvl1pPr/a:defRPr/@cap"))
    spc = el.xpath(".//a:lstStyle/a:lvl1pPr/a:defRPr/@spc")
    cols = max(1, int((el.xpath(".//a:bodyPr/@numCol") or [1])[0]))
    width = layout_ph.width / PT / cols
    per_char = size * (0.38 if face.startswith("Cormorant") else 0.47) * (1.2 if caps else 1) + (int(spc[0]) / 100 if spc else 0)
    lines = max(1, round(layout_ph.height / PT / max(line, 1))) * cols
    chars = max(4, int(width / max(per_char, 1)))
    while example and _lines_needed(example, chars) > lines and chars < 400:      # the example fits in the template: trust it
        chars += 1
    return lines, chars


def _accent(layout):
    """Burgundy on light layouts, rose on dark ones (olive, wine, dark photo)."""
    rgb = layout._element.xpath("./p:cSld/p:bg/p:bgPr/a:solidFill/a:srgbClr/@val")
    if rgb:
        r, g, b = (int(rgb[0][i:i + 2], 16) for i in (0, 2, 4))
        if 0.299 * r + 0.587 * g + 0.114 * b < 110:
            return "E4C3AE"
    return "8E2B39"


def _clean(value):
    """Text as the slide takes it: lists become lines, Windows line ends and markdown bold are normalised."""
    if isinstance(value, (list, tuple)):
        value = "\n".join(str(v) for v in value)
    text = str(value).replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"\*\*(.+?)\*\*", r"*\1*", text)          # **bold** by habit means the accent
    return text.strip("\n")


def _write(tf, text, accent):
    for p in list(tf.paragraphs)[1:]:
        p._p.getparent().remove(p._p)
    for i, line in enumerate(text.split("\n")):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        for r in list(p.runs):
            r._r.getparent().remove(r._r)
        for j, part in enumerate(re.split(r"\*([^*]+)\*", line)):
            part = part.replace("*", "")                    # an unpaired star never reaches the slide
            if not part:
                continue
            run = p.add_run()
            run.text = part
            if j % 2:
                run.font.italic = True
                run.font.color.rgb = RGBColor.from_string(accent)


def _background(slide, path, sw, sh):
    with Image.open(path) as im:
        iw, ih = im.size
    ir, sr = iw / ih, sw / sh
    l = t = 0
    if ir > sr:
        l = (1 - sr / ir) / 2
    else:
        t = (1 - ir / sr) / 2
    _, rid = slide.part.get_or_add_image_part(path)
    bg = parse_xml(
        f'<p:bg xmlns:a="{A}" xmlns:r="{R}" xmlns:p="{P}"><p:bgPr><a:blipFill dpi="0" rotWithShape="1"><a:blip r:embed="{rid}"/>'
        f'<a:srcRect l="{int(l * 1e5)}" t="{int(t * 1e5)}" r="{int(l * 1e5)}" b="{int(t * 1e5)}"/><a:stretch><a:fillRect/></a:stretch>'
        f'</a:blipFill><a:effectLst/></p:bgPr></p:bg>')
    csld = slide._element.find(f"{{{P}}}cSld")
    old = csld.find(f"{{{P}}}bg")
    if old is not None:
        csld.remove(old)
    csld.insert(0, bg)
